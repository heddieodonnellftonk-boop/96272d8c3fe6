// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Sample SSAO kernel"); }
int main(){
  announce();
  return lionss_run_workload("ssao_kernel");
}
