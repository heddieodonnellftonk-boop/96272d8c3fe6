// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Propagate orbit"); }
int main(){
  announce();
  return lionss_run_workload("orbit-propagate");
}
