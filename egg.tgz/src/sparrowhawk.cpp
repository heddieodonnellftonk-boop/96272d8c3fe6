// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Track sparrowhawk dive"); }
int main(){
  announce();
  return lionss_run_workload("sparrowhawk");
}
