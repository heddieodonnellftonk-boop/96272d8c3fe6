// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Render tallow burn"); }
int main(){
  announce();
  return lionss_run_workload("tallow");
}
